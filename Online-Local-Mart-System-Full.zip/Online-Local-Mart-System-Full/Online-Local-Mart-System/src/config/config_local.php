<?php

return [
    'db_driver' => 'mysql',
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'olms_full',
    'db_user' => 'root',
    'db_password' => '',
];