# Online Local Mart System (OLMS)

CSEB5223 Software Construction & Methods, Semester 1 2026/27, Section 01A.
Lecturer: Ts. Dr. Loo Yim Ling

A web-based local mart where customers browse and buy products and administrators manage
products, categories, inventory, customers and orders.

| No | Name | ID |
|----|------|----|
| 1 | Nur Maizatul Aishah binti Ahmad Rimi | BSW01085520 |
| 2 | Ainin Sufi binti Zuhari | BSW01085698 |
| 3 | Batyr Atayev | BSW01084241 |
| 4 | Emir Aiman bin Nasir | SW01084496 |

## 1. Technologies

| Component | Technology |
|-----------|------------|
| Frontend | HTML, CSS, JavaScript |
| Backend | PHP 8.x (no framework) |
| Database | MySQL |
| Version control | GitHub |

## 2. Progress

| Lab | Work | Status |
|-----|------|--------|
| Lab 1-2 | Pre-construction planning (Assignment Part 1) | Done |
| Lab 3-4 | Product module: create, search, edit, delete, display all | Done |
| Lab 5-6 | Remaining modules and system integration | Next |

## 3. How to run

1. Create the database (MySQL must be running):
   ```
   mysql -u root -p < src/database/schema_mysql.sql
   ```
   Or import `src/database/schema_mysql.sql` in phpMyAdmin.
2. Copy `src/config/config_local.example.php` to `src/config/config_local.php` and enter your MySQL password.
   This file is ignored by Git, so passwords are never pushed.
3. Start the site from the project folder:
   ```
   php -S localhost:8000
   ```
   Then open http://localhost:8000. With XAMPP, put the folder in `htdocs` and open
   `http://localhost/Online-Local-Mart-System/`.
4. Run the tests (they use a temporary in-memory database, not your MySQL data):
   ```
   php tests/run_tests.php
   ```

## 4. Folder structure

Follows Assignment Part 1, Section 5.2 (`config/` and `database/` added for settings and SQL).

```
Online-Local-Mart-System/
|-- index.php              front controller: reads ?action= and calls the controller
|-- assets/                css/style.css, js/app.js
|-- src/
|   |-- config/            app_constants.php, config.php, config_local.example.php
|   |-- database/          schema_mysql.sql, schema_sqlite.sql, setup_database.php
|   |-- models/            product.php, category.php
|   |-- controllers/       product_controller.php
|   |-- views/             layout/, products/, products/partials/
|   |__ services/          product_service.php, product_validator.php, category_service.php, ...
|-- tests/                 run_tests.php, product_service_test.php, product_validator_test.php
|-- docs/                  product_module.md
|-- README.md
└── .gitignore
```

## 5. Product module pages

| Page | URL | What it does |
|------|-----|--------------|
| All Products | `index.php?action=list` | Shows every product in a table |
| Add Product | `index.php?action=create` | Form with validation; the new row is highlighted after saving |
| Search | `index.php?action=search` | ID, keyword, category and price range; shows "Not found" when nothing matches |
| Edit | `index.php?action=edit_search` | Find -> edit form -> before/after comparison |
| Delete | `index.php?action=delete_search` | Find -> confirm with full details -> result with counts before/after |

More detail, including the method documentation, is in [docs/product_module.md](docs/product_module.md).

## 6. Team rules (summary)

- Naming: classes `PascalCase`, variables and methods `camelCase`, constants `UPPER_SNAKE_CASE`,
  files `snake_case.php`, folders `lowercase`, tables and columns `snake_case`.
- Each important method has a comment block with Function/Method Name, Purpose, Parameters,
  Return Value and Description.
- Work on your own branch (for example `feature/product-module`), never directly on `main`.
  Open a pull request; the team reviews it and CI must pass before merging.
